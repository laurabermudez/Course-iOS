//
//  main.m
//  ListaNumeros
//
//  Created by Estudiantes on 2/11/17.
//  Copyright © 2017 gv. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
