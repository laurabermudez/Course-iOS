//
//  ColorsTableViewController.h
//  ListaNumeros
//
//  Created by Estudiantes on 2/11/17.
//  Copyright © 2017 gv. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ColorsTableViewController : UITableViewController

//@property (nonatomic,strong) NSArray *colors;

@end
