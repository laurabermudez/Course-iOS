//
//  ViewController.h
//  Quiz4
//
//  Created by Estudiantes on 2/25/17.
//  Copyright © 2017 gv. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

