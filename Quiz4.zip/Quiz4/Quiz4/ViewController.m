//
//  ViewController.m
//  Quiz4
//
//  Created by Estudiantes on 2/25/17.
//  Copyright © 2017 gv. All rights reserved.
//

#import "ViewController.h"
#import "NumberViewController.h"

@interface ViewController ()<UITableViewDelegate, UITableViewDataSource>

@property (nonatomic,strong) NSMutableArray *dataSource;@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
